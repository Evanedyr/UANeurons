addprocs(20)
@everywhere include("MyFunc.jl")
################### run simulation of 2comp model ##################
Ra = 0.009;
C0 = 250.;
t = 0.;           # starting time
tstim = 0.;
const dt = 0.005;       # simulation's time step
tstim_dur = 100000.; # duration of the simulation
tstimcon = Inf;
tstimcon_dur = Inf;
N = Int(floor(tstim_dur/dt));  # number of points
noisevar = zeros(Float64, N);
V = zeros(Float64, N, 4);
inters = readdlm("Intersections$(Ra).jl")
std = inters[1,3];
amp = 0.36*500.;
tau = 10.;
spikes = [];
Vs = [];
mytime = [];
nbins = 50.
fRange1 = 0.001:(.01-.001)/nbins:0.009
fRange2 = 0.01:(.1-.01)/nbins:0.09
fRange3 = 0.1:(1.-.1)/nbins:1.
fRange = [fRange1; fRange2; fRange3]; #Range of frequencies to study
param = readdlm("EIFparam$(Ra)Ra.jl")
taum = param[1]
El0 = param[2]
sf0 = param[3]
Vth0 = param[4]
for mode = 1:2
	Ipeak = inters[1,mode];
	for loop= 1:10
		@sync @parallel for i =1:length(fRange)
			freq = fRange[i]
			noisevar = zeros(Float64, N);
			V = zeros(Float64, N, 4);
			noisevar = simulate_ou!(noisevar, N, 0., dt, 0., std, tau) #noise
			Vr = -85.
			Vexp, mytime = exponential_model(C0, taum, El0, sf0, Vth0, Vr, Ra, dt, N, freq, amp, Ipeak, noisevar)#, sf2, taum2, Vth2)
			spikes = FindMax(Vexp, mytime, -20.)
			writedlm("OUTPUT/spktrain$(loop)loop$(mode)sfrmode$(std)std$(freq)KHz.txt", spikes)
		end
	end
end
rmprocs(workers(), waitfor = 10)
print(workers())
